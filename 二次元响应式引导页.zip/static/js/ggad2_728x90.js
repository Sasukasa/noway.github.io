document.writeln("<link type=\"text/css\" rel=\"stylesheet\" href=\"http://www.cssmoban.com/statics/css/astyle.css\" />");
document.writeln("<div align=\"center\">");
document.writeln("<a href=\'http://www.cssmoban.com/item/Getclick.asp?Action=Count&GetFlag=0&m=1&ID=8\' rel=\'nofollow\' target=\'_blank\'><img src=\'http://www.cssmoban.com/UploadFiles/2020/2/202002161520324123.jpg\' alt=\'\' border=\'0\' style=\'height: 90px!important;width:970px!important;\'></a>");
document.writeln("</div>");